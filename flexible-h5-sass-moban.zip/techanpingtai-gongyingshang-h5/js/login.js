/**
 * Created by Administrator on 2019/1/29.
 */
$(document).ready(function () {
	$(".login_btn").click(function(){
		var username=$("#username").val();
		var password=$("#password").val();
		if(username==""){
			layer.open({
			    content: '请输入账号'
			    ,skin: 'msg'
			    ,time: 2 //2秒后自动关闭
			});
		}else if(password==""){
			layer.open({
			    content: '请输入密码'
			    ,skin: 'msg'
			    ,time: 2 //2秒后自动关闭
			});
		}
	})
	$("#editPass").click(function(){
		var oldpsd=$("#oldpsd").val();
		var newpsd=$("#newpsd").val();
		var confrmpass=$("#confrmpass").val();
		if(oldpsd==""){
			layer.open({
			    content: '请输入原密码'
			    ,skin: 'msg'
			    ,time: 2 //2秒后自动关闭
			});
		}else if(newpsd==""){
			layer.open({
			    content: '请输入新密码'
			    ,skin: 'msg'
			    ,time: 2 //2秒后自动关闭
			});
		}
		else if(confrmpass==""){
			layer.open({
			    content: '请输入确认密码'
			    ,skin: 'msg'
			    ,time: 2 //2秒后自动关闭
			});
		}
		else if(confrmpass!=newpsd){
			layer.open({
			    content: '新密码与确认密码不一致'
			    ,skin: 'msg'
			    ,time: 2 //2秒后自动关闭
			});
		}
	})
});