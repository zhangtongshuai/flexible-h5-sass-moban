/**
 * Created by Administrator on 2019/1/14.
 */
$(document).ready(function () {
    $('.footer_info ul').find('li').on('click',function () {
        $("ul li").eq($(this).index()).addClass("active").siblings().removeClass('active');
    });

});